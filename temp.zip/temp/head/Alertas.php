	<script type="text/javascript">
		$(document).ready(function() {
			<?php
				$_SESSION["erro"] = 'erro';
				$_SESSION["alert"] = 'alert-danger';
				$_SESSION["text"] = 'Usuário ou senha inválidos';
				$_SESSION["strong"] = 'Erro!';
			?>
			$('#alerta').modal('show');
		})
	</script>

	<div class="modal fade" tabindex="-1" role="dialog" id="alerta">
		<div class="modal-dialog" role="document">
			<div class="alert <?=$_SESSION['alert']?> alert-dismissible fade show" role="alert">
				<strong><?=$_SESSION['strong']?></strong> <?=$_SESSION['text']?>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
		</div>
	</div>
  
<?php 
	unset($_SESSION['erro']); 
	unset($_SESSION['alert']); 
	unset($_SESSION['text']); 
	unset($_SESSION['strong']); 
?>
